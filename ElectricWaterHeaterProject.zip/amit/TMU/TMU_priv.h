/*
 * TMU_priv.h
 *
 *  Created on: Aug 19, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef TMU_TMU_PRIV_H_
#define TMU_TMU_PRIV_H_

typedef struct 
{
    void(*schedTask)(void);
    u16 u16Periodicity;
}TCB_t;

#define TIMER0          32
#define TIMER1          87
#define TIMER2          24


#define TCCR0               *((u8*)0x53)
#define TCNT0               *((u8*)0x52)
#define OCR0                *((u8*)0x5C)
#define TIMSK               *((u8*)0x59)
#define TIFR                *((u8*)0x58)


#endif /* TMU_TMU_PRIV_H_ */
