/*
 * TMU_prog.c
 *
 *  Created on: Aug 19, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../Lib/stdTypes.h"

#include "TMU_config.h"
#include "TMU_priv.h"
#include "TMU_int.h"

static u32 TMU_u32OsTicks = 0;

#if (TMU_TIMER_CHNL == TIMER0) || (TMU_TIMER_CHNL == TIMER2)
    static u16 TMU_u16OvfCounts = 0;
    static u16 TMU_u16ISRCounts = 0;
    static u8 TMU_u8Preload = 0;
#endif

#if (TMU_MAX_TASK_NUM >0) && (TMU_MAX_TASK_NUM <=10)
    static TCB_t TMU_astrTasks[TMU_MAX_TASK_NUM] ={0};
#else   
    #error MAX num of Tasks in TMU is invalid
#endif

void TMU_vidInit(void)
{
    #if TMU_TIMER_CHNL == TIMER0
        #if (TMU_OS_TICK >0) && (TMU_OS_TICK <= 200)
            u32 Local_u32Counts = ((u64)TMU_OS_TICK * TMU_CPU_FREQ)/ (1024ULL);
            TMU_u16OvfCounts = (Local_u32Counts + 255) / 256UL;
            TMU_u8Preload = 256UL - ((Local_u32Counts % 256UL));

            TMU_u16ISRCounts = TMU_u16OvfCounts;
            // Ovf , disconnect OC0 pin , 1024 prescaler
            TCCR0 = 0x05;
            TCNT0 = TMU_u8Preload;
            TIMSK |= (1<<0);
        #else
            #error Invalid OS tick time
        #endif
    #elif TMU_TIMER_CHNL == TIMER1
    
    #elif TMU_TIMER_CHNL == TIMER2

    #else   
        #error Timer selected in TMU is invalid
    #endif
}

void TMU_vidCreateTask(void(*Copy_pFunAppTask)(void), u16 Copy_u16Periodicity , u8 Copy_u8Priority)
{
    if ((Copy_u8Priority < TMU_MAX_TASK_NUM) && (Copy_u16Periodicity > 0))
    {
        TMU_astrTasks[ Copy_u8Priority ].schedTask      = Copy_pFunAppTask;
        TMU_astrTasks[ Copy_u8Priority ].u16Periodicity = Copy_u16Periodicity;
    }
}

void TMU_vidStartScheduler(void)
{
    s8 Local_s8Iter = TMU_MAX_TASK_NUM -1 ;
    u32 Local_u32CurrentOsTick = 0;
    asm("sei");
    while(1)
    {
        if (TMU_u32OsTicks > Local_u32CurrentOsTick)
        {
            Local_u32CurrentOsTick = TMU_u32OsTicks;
            
            for (Local_s8Iter = TMU_MAX_TASK_NUM -1 ; Local_s8Iter >= 0; Local_s8Iter--)
            {
                if (((TMU_u32OsTicks % TMU_astrTasks[Local_s8Iter].u16Periodicity) == 0)
                        && (TMU_astrTasks[Local_s8Iter].schedTask != NULL))
                {
                    TMU_astrTasks[Local_s8Iter].schedTask ();
                }
            }
        }
    }
}


#if TMU_TIMER_CHNL == TIMER0

//void __vector_11 (void)__attribute__((signal));
//void __vector_11 (void)
//{
  //  TMU_u16ISRCounts --;
    //if (TMU_u16ISRCounts == 0)
    //{
      //  TCNT0 = TMU_u8Preload;

        //TMU_u32OsTicks++;

        //TMU_u16ISRCounts = TMU_u16OvfCounts;
//    }
//}

#elif TMU_TIMER_CHNL == TIMER1

#elif TMU_TIMER_CHNL == TIMER2

#else   
    #error Timer selected in TMU is invalid
#endif
