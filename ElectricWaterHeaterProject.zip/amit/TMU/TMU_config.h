/*
 * TMU_config.h
 *
 *  Created on: Aug 19, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef TMU_TMU_CONFIG_H_
#define TMU_TMU_CONFIG_H_

        // TIMER0 , TIMER1 , TIMER2
#define TMU_TIMER_CHNL              TIMER0

        // write freq in KHz
#define TMU_CPU_FREQ                16000UL

        // write OS Tick in ms "Don't exceed 200 ms"
#define TMU_OS_TICK                     5

        // Write Num Of Tasks "Don't exceed 10 tasks"
#define TMU_MAX_TASK_NUM                3
#endif /* TMU_TMU_CONFIG_H_ */
