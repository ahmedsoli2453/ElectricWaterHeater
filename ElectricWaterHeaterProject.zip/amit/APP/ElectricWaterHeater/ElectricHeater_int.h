/*
 * ElectricHeater_int.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef APP_ELECTRICWATERHEATER_ELECTRICHEATER_INT_H_
#define APP_ELECTRICWATERHEATER_ELECTRICHEATER_INT_H_
#include "../../Lib/stdTypes.h"
void ElectricHeater_init(void);
void callback_ONOFF(void);
void callback_UP(void);
void callback_DOWN(void);
void callback_Timer2(void);
void AdjustTemperature_Task(void*pv);
void SevenSegments_Task(void*pv);
void LED_task(void*pv);
void checkSeconds_Task(void);
void SevenSegmentsSetting_Task(void);
u8 getDesiredTemperature();
void DisplaySevenSegments(u8 sevenSegmentsTicks,u8 temp);
void setDesiredTemperature(u8 Temp);
void debounce();
//void vApplicationIdleHook( void );
u16 getAverageTemperature();









volatile  u8 status;

//volatile  u8 status = 255;
 //u16 currentSecondsCount;
u32 TemporaryVariable;
 u8 currentTemperatureCount;
volatile  u16 currentTemperature;
 volatile u8 setTemperature;
 u16 temperatures[10];
 u16 averageTemperature;
volatile  u16 sevenSegmentsTicks;
 //u16 sevenSegmentsSettingsCount;
 u8 sevenSegmentsSettingsFlag;

#endif /* APP_ELECTRICWATERHEATER_ELECTRICHEATER_INT_H_ */
