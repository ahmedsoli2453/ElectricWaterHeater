/*
 * ElectricHeater_config.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef APP_ELECTRICWATERHEATER_ELECTRICHEATER_CONFIG_H_
#define APP_ELECTRICWATERHEATER_ELECTRICHEATER_CONFIG_H_



#endif /* APP_ELECTRICWATERHEATER_ELECTRICHEATER_CONFIG_H_ */
