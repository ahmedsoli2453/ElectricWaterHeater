/*
 * ElectricWaterHeater_prog.c
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */
/*
#include "../../Lib/stdTypes.h"


#include "../../MCAL/EEPROM/EEPROM_int.h"
#include "../../MCAL/EXTI/EXTI_int.h"
#include "../../MCAL/Timer2/Timer2_int.h"

#include "../../HAL/TemperatureSensor/Temp_int.h"
#include "../../HAL/HexaDecoder/HexaDecoder_int.h"
#include "../../TMU/TMU_int.h"
#include "../../HAL/HeaterLED/HeaterLED_int.h"
#include "../../HAL/HeatingElement/HeatingElement_int.h"
#include "../../HAL/CoolingElement/CoolingElement_int.h"
#include "../../HAL/SegmentsEnable/SegmentsEnable_int.h"

#include "ElectricHeater_int.h"
#include "ElectricHeater_config.h"
#include <util/delay.h>
//#include "../../HAL/EEPROM/EEPROM_int.h"


#define STATUS_OFF 0
#define STATUS_SETTING 1
#define STATUS_HEATING 2
#define STATUS_COOLING 3

#define FLAG_ON 1
#define FLAG_OFF 0

#define CHECK_5_SECONDS 305
#define DESIRED_TEMPERATURE_ADDRESS 0x01

static u8 status = 0;
static u16 currentSecondsCount = 0;
static u8 currentTemperatureCount = 0;
static f32 currentTemperature = 0;
static f32 setTemperature = 60;
static f32 temperatures[10];
static f32 averageTemperature = 0;
static u16 sevenSegmentsTicks = 0;
static u16 sevenSegmentsSettingsCount = 0;
static u8 sevenSegmentsSettingsFlag = 0;

//int main(){ElectricHeater_init();return 0;}

void ElectricHeater_init(void){
	//This function initializes Temperature sensor, EXTI ,TMU,EEPROM and finally add necessary tasks

	//Initializations

	Timer2_vidInit();
	Timer2_vidCallBack(callback_Timer2);


	    TemperatureSenor_init();
	    HeaterLED_init();
		HeatingElement_init();
		CoolingElement_init();
		HexaDecoder_vidInit();
		segment_init();
		//disable_segment(1);disable_segment(2);
		HexaDecoder_vidEnable(SSG_ID_1);
		HexaDecoder_vidEnable(SSG_ID_2);
		__asm__ __volatile__ ("sei" ::);
	EXTI_vidInit();
	EXTI_vidSetCallBack(callback_ONOFF, EXTI_INT_0);
	EXTI_vidSetCallBack(callback_UP, EXTI_INT_1);
	EXTI_vidSetCallBack(callback_DOWN, EXTI_INT_2);
	EXTI_vidSetSenseLevel(EXTI_INT_0 ,EXTI_RISING);
	EXTI_vidSetSenseLevel(EXTI_INT_1 ,EXTI_RISING);
	EXTI_vidSetSenseLevel(EXTI_INT_2 ,EXTI_RISING);
	EXTI_vidEnableInterrupt(EXTI_INT_0);
	EXTI_vidEnableInterrupt(EXTI_INT_1);
	EXTI_vidEnableInterrupt(EXTI_INT_2);
	//asm("sei");
	//EEPROM_init();



	//set or retrieve desired temperature from EEPROM
	f32 temp = getDesiredTemperature();
	if(temp>=35 && getDesiredTemperature()<=75){
		setTemperature = temp;
	}



	//NecesaryTasks
	//TMU_vidInit();
	//TMU_vidCreateTask(SevenSegments_Task, 20 , 2);
	//TMU_vidCreateTask(LED_task, 10 , 1);
	//TMU_vidCreateTask(AdjustTemperature_Task, 5 , 0);
	//TMU_vidStartScheduler();
	u16 num;
	while(1){
		num = readTemperature();
		if(num<60){
		HeatingElement_ON();CoolingElement_OFF();
	}
	else{
		HeatingElement_OFF();CoolingElement_ON();
	}}
}

void callback_Timer2(void){
	__asm__ __volatile__ ("cli" ::);
	if(sevenSegmentsSettingsCount++==61){
		sevenSegmentsSettingsCount = 0;
		sevenSegmentsSettingsFlag ^=1;

	}
	if(currentSecondsCount++>=CHECK_5_SECONDS){
		currentSecondsCount = 0;
		status = STATUS_HEATING;
		setDesiredTemperature(setTemperature);
		Timer2_vidDisableOInterrupt();
	}

	__asm__ __volatile__ ("sei" ::);
}
void callback_ONOFF(void){
	debounce();
	HeaterLED_Toggle();
if(status==STATUS_OFF){
	status = STATUS_HEATING;
	//HeaterLED_ON();
}
else{
	status = STATUS_OFF;
	//HeaterLED_OFF();
}

}

void callback_UP(void){
	debounce();
	currentSecondsCount=0;
status = STATUS_SETTING;
if(setTemperature <=70){
setTemperature = setTemperature +5;
}
Timer2_vidEnableOInterrupt();
}

void callback_DOWN(void){
	debounce();
status = STATUS_SETTING;
currentSecondsCount=0;
if(setTemperature >=40){
setTemperature = setTemperature -5;
}
Timer2_vidEnableOInterrupt();
}

void AdjustTemperature_Task(void){
	if(status == STATUS_OFF){
		HeatingElement_OFF();
		CoolingElement_OFF();
	}
if(status != STATUS_OFF && status != STATUS_SETTING){
currentTemperature = readTemperature();
temperatures[currentTemperatureCount++%10] = currentTemperature;
averageTemperature = getAverageTemperature();
if(averageTemperature<=setTemperature-5){
	status = STATUS_HEATING;
	HeatingElement_ON();
	CoolingElement_OFF();
}
if(averageTemperature >= setTemperature+5){
	status = STATUS_COOLING;
	HeatingElement_OFF();
	CoolingElement_ON();
}

}
}

void SevenSegments_Task(void){

if(status == STATUS_OFF){
	//HexaDecoder_vidDisable(SSG_ID_1);
	//HexaDecoder_vidDisable(SSG_ID_2);
	disable_segment(1);disable_segment(2);
}
if(status == STATUS_SETTING){
	sevenSegmentsTicks++;
	if(sevenSegmentsSettingsFlag==FLAG_ON){
		//HexaDecoder_vidEnable(SSG_ID_1);
		//HexaDecoder_vidEnable(SSG_ID_2);
		enable_segment(1);enable_segment(2);
		DisplaySevenSegments(sevenSegmentsTicks,setTemperature);
	}
	else{
		//HexaDecoder_vidDisable(SSG_ID_1);
		//HexaDecoder_vidDisable(SSG_ID_2);
		disable_segment(1);
		disable_segment(2);
	}

}
else{
	sevenSegmentsTicks++;
	DisplaySevenSegments(sevenSegmentsTicks,currentTemperature);



}

}


void LED_task(void){
if(status ==STATUS_HEATING){
	HeaterLED_Toggle();
}
if(status == STATUS_OFF){
	HeaterLED_OFF();
}

else{
	HeaterLED_ON();
}

}



void DisplaySevenSegments(u8 sevenSegmentsTicks,f32 temp){
	u8 currentCase = sevenSegmentsTicks%4;
	if(currentCase ==0){
		//HexaDecoder_vidEnable(SSG_ID_1);
		enable_segment(1);
		//HexaDecoder_vidDisable(SSG_ID_2);
		disable_segment(2);
		HexaDecoder_vidDisplayNum((u8)temp/10);
	}
	if(currentCase == 1){

	}
	if(currentCase == 2){
			//HexaDecoder_vidEnable(SSG_ID_2);
		enable_segment(2);
			//HexaDecoder_vidDisable(SSG_ID_1);
		disable_segment(1);
			HexaDecoder_vidDisplayNum((u8)temp%10);
	}
	if(currentCase == 3){

	}


}


s16 getDesiredTemperature(){

	s16 temp;
	temp = EEPROM_read(DESIRED_TEMPERATURE_ADDRESS);
	return temp;
}


void setDesiredTemperature(s16 Temp){

	EEPROM_write(DESIRED_TEMPERATURE_ADDRESS, Temp);
}

f32 getAverageTemperature(){
	f32 sum = 0;
	for(int i = 0;i<10;i++){
		sum = sum + temperatures[i];
	}
	return sum/10.0;
}
void debounce(){
	__asm__ __volatile__ ("cli" ::);
	//for(int i = 0 ;i<2000;i++);
	_delay_ms(10);
	__asm__ __volatile__ ("sei" ::);
}*/


