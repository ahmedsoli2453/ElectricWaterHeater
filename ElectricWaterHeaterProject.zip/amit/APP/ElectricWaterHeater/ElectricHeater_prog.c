/*
 * ElectricHeater_prog.c
 *
 *  Created on: Sep 11, 2023
 *      Author: ahmed
 */
#include "../../Lib/stdTypes.h"


#include "../../MCAL/EEPROM/EEPROM_int.h"
#include "../../MCAL/EXTI/EXTI_int.h"
#include "../../MCAL/ADC/ADC_int.h"
//#include "../../MCAL/Timer2/Timer2_int.h"

#include "../../HAL/TemperatureSensor/Temp_int.h"
#include "../../HAL/HexaDecoder/HexaDecoder_int.h"
//#include "../../TMU/TMU_int.h"
#include "../../HAL/HeaterLED/HeaterLED_int.h"
#include "../../HAL/HeatingElement/HeatingElement_int.h"
#include "../../HAL/CoolingElement/CoolingElement_int.h"
#include "../../HAL/SegmentsEnable/SegmentsEnable_int.h"

#include "ElectricHeater_int.h"
#include "ElectricHeater_config.h"

//#include "../../FreeRTOS/AVR_REG.h"
#include "../../FreeRTOS/FreeRTOS.h"
#include "../../FreeRTOS/task.h"

#include "../../FreeRTOS/BIT_MATH.h"

//#include <util/delay.h>
//#include "../../HAL/EEPROM/EEPROM_int.h"


#define STATUS_OFF 0
#define STATUS_SETTING 1
#define STATUS_HEATING 2
#define STATUS_COOLING 3

#define FLAG_ON 1
#define FLAG_OFF 0

#define CHECK_5_SECONDS 305
#define DESIRED_TEMPERATURE_ADDRESS 0x00





int main(){

	status = 255;
	//currentSecondsCount = 0;
	currentTemperatureCount = 0;
	currentTemperature = 12;
	setTemperature = 60;
	//if(getDesiredTemperature() !=0){
		//setTemperature = getDesiredTemperature();
	//}

	//temperatures[10];
	averageTemperature = 0;
	sevenSegmentsTicks = 255;
	//sevenSegmentsSettingsCount = 0;
	sevenSegmentsSettingsFlag = 0;

	//status = 0;
	TemperatureSenor_init();
	HeaterLED_init();
	HeatingElement_init();
	CoolingElement_init();
	HexaDecoder_vidInit();

	__asm__ __volatile__ ("sei" ::);
	EXTI_vidInit();
	EXTI_vidSetCallBack(callback_ONOFF, EXTI_INT_0);
	EXTI_vidSetCallBack(callback_UP, EXTI_INT_1);
	EXTI_vidSetCallBack(callback_DOWN, EXTI_INT_2);
	EXTI_vidSetSenseLevel(EXTI_INT_0 ,EXTI_RISING);
	EXTI_vidSetSenseLevel(EXTI_INT_1 ,EXTI_RISING);
	EXTI_vidSetSenseLevel(EXTI_INT_2 ,EXTI_RISING);
	EXTI_vidEnableInterrupt(EXTI_INT_0);
	EXTI_vidEnableInterrupt(EXTI_INT_1);
	EXTI_vidEnableInterrupt(EXTI_INT_2);







	xTaskCreate(LED_task,NULL,configMINIMAL_STACK_SIZE,NULL,1,NULL);
	xTaskCreate(SevenSegments_Task,NULL,configMINIMAL_STACK_SIZE,NULL,1,NULL);
	xTaskCreate(AdjustTemperature_Task,NULL,configMINIMAL_STACK_SIZE,NULL,1,NULL);
	//portENABLE_INTERRUPTS();
	vTaskStartScheduler();
	//while(1){}
	return 0;
}


void AdjustTemperature_Task(void*pv){
	while(1){


	if(status == STATUS_OFF){
		HeatingElement_OFF();
		CoolingElement_OFF();
		vTaskDelay(100);

	}
	else if(status == STATUS_HEATING || status == STATUS_COOLING){
		//__asm__ __volatile__ ("cli" ::);
		//currentTemperature = readTemperature();
		//currentTemperature = ADC_u8ReadPolling(0);
		//__asm__ __volatile__ ("sei" ::);
		//HeatingElement_ON();
		ADC_vidStartConversion();
//				CoolingElement_ON();
		while (ADCSRA & (1 << 6)){
				vTaskDelay(1);}
				//HeatingElement_OFF();
		//currentTemperature = ADCH;
		currentTemperature = ADCL; /* Read the low byte */
		currentTemperature = (currentTemperature+(ADCH<<8)); /* Read and add the high byte */
		//TemporaryVariable = currentTemperature*500;
		//TemporaryVariable = currentTemperature/1024;
		//currentTemperature = (TemporaryVariable&0xffff);
		temperatures[currentTemperatureCount++%10] = currentTemperature*100/1024*5;
		averageTemperature = (u16)getAverageTemperature();
		if(averageTemperature<=setTemperature-5){
			status = STATUS_HEATING;
			HeatingElement_ON();
			CoolingElement_OFF();
			//vTaskDelay(100);
		}
		else if(averageTemperature >= setTemperature+5){
			status = STATUS_COOLING;
			HeatingElement_OFF();
			CoolingElement_ON();
			//vTaskDelay(100);
		}


//						CoolingElement_OFF();
						vTaskDelay(100);

	}
	//else if(status != STATUS_OFF && status != STATUS_SETTING){
//currentTemperature = readTemperature();
	//ADC_vidStartConversion();
		//while (ADCSRA & (1 << 6)) {
		  ///          vTaskDelay(100); // Adjust the delay as needed
		     //   }
		//currentTemperature = ADCL;
/*temperatures[currentTemperatureCount++%10] = currentTemperature;
averageTemperature = getAverageTemperature();
if(averageTemperature<=setTemperature-5){
	status = STATUS_HEATING;
	HeatingElement_ON();
	CoolingElement_OFF();
	//vTaskDelay(100);
}
if(averageTemperature >= setTemperature+5){
	status = STATUS_COOLING;
	HeatingElement_OFF();
	CoolingElement_ON();
	//vTaskDelay(100);
}
vTaskDelay(100);
}
	HeatingElement_ON();
	vTaskDelay(100);
	HeatingElement_OFF();
*/
}
}



void LED_task(void*pv){
	while(1){
	if(status ==STATUS_HEATING){
		HeaterLED_ON();
		vTaskDelay(1000);
		HeaterLED_OFF();
		vTaskDelay(1000);
	}
	if(status == STATUS_OFF){
		HeaterLED_OFF();
		vTaskDelay(1000);
		//HeaterLED_ON();
		//vTaskDelay(1000);
		//HeaterLED_OFF();
		//vTaskDelay(1000);
	}

	else{
		HeaterLED_ON();
		vTaskDelay(1000);
	}

	//vTaskDelay(1000);
}
}
void SevenSegments_Task(void*pv){
while(1){


	if(status == STATUS_OFF){
		HexaDecoder_vidDisable(SSG_ID_1);
		HexaDecoder_vidDisable(SSG_ID_2);
		//disable_segment(1);disable_segment(2);

		vTaskDelay(1000);
	}
	else if(status == STATUS_SETTING){
		sevenSegmentsTicks++;
		if(sevenSegmentsTicks >4){
			if(currentTemperature<setTemperature){
			status = STATUS_HEATING;}
			else{
				status = STATUS_COOLING;
			}
			//__asm__ __volatile__ ("cli" ::);
			//setDesiredTemperature(setTemperature);
			//__asm__ __volatile__ ("sei" ::);
		}
		if(sevenSegmentsSettingsFlag==FLAG_ON){


			HexaDecoder_vidEnable(SSG_ID_1);
			HexaDecoder_vidEnable(SSG_ID_2);
			//enable_segment(1);enable_segment(2);
			DisplaySevenSegments(sevenSegmentsTicks,setTemperature);


			sevenSegmentsSettingsFlag^=1;
			//vTaskDelay(1000);

		}
		else{

			HexaDecoder_vidDisable(SSG_ID_1);
			HexaDecoder_vidDisable(SSG_ID_2);


			sevenSegmentsSettingsFlag^=1;
			//vTaskDelay(1000);
			//disable_segment(1);
			//disable_segment(2);

		}
		vTaskDelay(1000);
	}
	else{

		DisplaySevenSegments(sevenSegmentsTicks,averageTemperature);


		vTaskDelay(1000);
	}


}
}



void callback_ONOFF(void){
	//debounce();
	//HeaterLED_Toggle();
if(status==STATUS_OFF){
	status = STATUS_HEATING;
	//HeaterLED_ON();
}
else{
	status = STATUS_OFF;
	//HeaterLED_OFF();
}

}

void callback_UP(void){
	//debounce();
	//currentSecondsCount=0;
status = STATUS_SETTING;
sevenSegmentsTicks = 0;
if(setTemperature <=70){
setTemperature = setTemperature +5;
}
//Timer2_vidEnableOInterrupt();
}

void callback_DOWN(void){
	//debounce();
status = STATUS_SETTING;
//currentSecondsCount=0;
sevenSegmentsTicks = 0;
if(setTemperature >=40){
setTemperature = setTemperature -5;
}
//Timer2_vidEnableOInterrupt();
}

u8 getDesiredTemperature(){

	u8 temp;
	temp = EEPROM_read(DESIRED_TEMPERATURE_ADDRESS);
	return temp;
}


void setDesiredTemperature(u8 Temp){

	EEPROM_write(DESIRED_TEMPERATURE_ADDRESS, Temp);
}

u16 getAverageTemperature(){
	u16 sum = 0;
	for(int i = 0;i<10;i++){
		sum = sum + temperatures[i];
	}
	return sum/10;
}
void debounce(){
	__asm__ __volatile__ ("cli" ::);
	//for(int i = 0 ;i<2000;i++);
	//_delay_ms(10);
	__asm__ __volatile__ ("sei" ::);
}

void DisplaySevenSegments(u8 sevenSegmentsTicks,u8 temp){
	HexaDecoder_vidEnable(SSG_ID_1);HexaDecoder_vidEnable(SSG_ID_2);
	 HexaDecoder_vidDisplayNum((u8)temp%10);

	 HexaDecoder_vidDisplayNum2((u8)(temp/10));
}

//void vApplicationIdleHook( void ){
	//while(1);
//}

