/*
 * main.c
 *
 *  Created on: Aug 27, 2023
 *      Author: ahmed
 */

//#include "ElectricWaterHeater/ElectricHeater_int.h"
#include "../Lib/stdTypes.h"


#include "../MCAL/DIO/DIO_int.h"
#include "../MCAL/EXTI/EXTI_int.h"
#include "../MCAL/ADC/ADC_int.h"
#include "../MCAL/ADC/ADC_priv.h"
#include "../MCAL/Timer0/Timer0_int.h"

#include "../HAL/LCD/LCD_int.h"
#include "../HAL/TemperatureSensor/Temp_int.h"
#include "../HAL/HeaterLED/HeaterLED_int.h"
#include "../HAL/HexaDecoder/HexaDecoder_int.h"
#include "ElectricWaterHeater/ElectricHeater_int.h"
//#include <util/delay.h>
//void callback(void);


u8 count = 5;
u16 timer2_count = 500;
void SevenSegments_disp(void);
void callback(void);
void callback2(void);
void callback_timer2(void);



/*int main(){
	Timer0_vidInit();
		Timer_vidCallBack(callback_timer2);
		Timer0_vidSetCompareCount(250);
		HexaDecoder_vidInit();
		asm("sei");


	while(1){
		SevenSegments_disp();
	}
	return 0;
}*/


//int main(){
	//DIO_vidSetPinDirection(DIO_GROUP_A,DIO_PIN_0,DIO_INPUT);
	//HexaDecoder_vidInit();
	//ADC_vidInit();

//	u16 currentTemperature = 0;




	//while(1){
		//ADC_vidStartConversion();
		//				CoolingElement_ON();
			//	while (ADCSRA & (1 << 6)){
					//	}
						//HeatingElement_OFF();
				//currentTemperature = ADCH;

				//currentTemperature = ADCL; /* Read the low byte */
			//	currentTemperature += (ADCH<<8);
				/* Read and add the high byte */
				//currentTemperature = currentTemperature%100;
				//DisplaySevenSegments(1,currentTemperature);
	//}
	//return 0;
//}*/


/*
int main(){

	Timer0_vidInit();
	Timer_vidCallBack(callback_timer2);
	//Timer0_vidSetCompareCount(250);
	//Timer_vidEnableInterrupt();
	//EXTI_vidInit();
	HexaDecoder_vidInit();
	//EXTI_vidSetSenseLevel(EXTI_INT_1 , EXTI_RISING);
	//EXTI_vidSetCallBack(callback, EXTI_INT_1);
	//EXTI_vidEnableInterrupt(EXTI_INT_1);
	//EXTI_vidSetSenseLevel(EXTI_INT_2 , EXTI_RISING);
		//EXTI_vidSetCallBack(callback2, EXTI_INT_2);
		//EXTI_vidEnableInterrupt(EXTI_INT_2);
	__asm__ __volatile__ ("sei" ::);


	while(1){
		SevenSegments_disp();

	}
}
*/



void callback(void){
	EXTI_vidDisableInterrupt(EXTI_INT_0);
	///_delay_ms(10);
	count=count+5;
	timer2_count = 0;
	Timer_vidEnableInterrupt();
	EXTI_vidEnableInterrupt(EXTI_INT_0);

}

void callback2(void){
	EXTI_vidDisableInterrupt(EXTI_INT_0);
	//_delay_ms(10);
	count=count-5;
	timer2_count = 0;
	Timer_vidEnableInterrupt();
	EXTI_vidEnableInterrupt(EXTI_INT_0);

}

void callback_timer2(void){
	count++;
//timer2_count++;
}

void SevenSegments_disp(void){


	/*if(timer2_count <1){
	HexaDecoder_vidEnable(SSG_ID_1);HexaDecoder_vidEnable(SSG_ID_2);
	HexaDecoder_vidDisplayNum(count%10);
	HexaDecoder_vidDisplayNum2(count/10);
	_delay_ms(1000);
	HexaDecoder_vidDisable(SSG_ID_1);HexaDecoder_vidDisable(SSG_ID_2);
	_delay_ms(1000);}
	else{*/
		//Timer_vidDisableInterrupt();
		HexaDecoder_vidEnable(SSG_ID_1);HexaDecoder_vidEnable(SSG_ID_2);
			HexaDecoder_vidDisplayNum(count%10);
			HexaDecoder_vidDisplayNum2(count/10);
			//_delay_ms(1000);
			//HexaDecoder_vidDisable(SSG_ID_1);HexaDecoder_vidDisable(SSG_ID_2);
			//_delay_ms(1000);
	//}

}




/*int main(){
	ADC_vidInit();
	LCD_enuInit();
	HeaterLED_init();
	u16 num;
	//TemperatureSenor_init();
	while(1){

		num = ADC_u16ReadPolling(1);
		if(num<40){
			HeaterLED_ON();
		}
		LCD_vidSendCommand(0x01);
		_delay_ms(10);
		LCD_vidSendCommand(0x81);
		_delay_ms(10);
		LCD_vidWriteIntegarNum(num);
		_delay_ms(10);
		}
	return 0;}
*/
/*int main(){


//	ElectricHeater_init();




//	DIO_vidSetPinDirection(0, 1, 1);
//	DIO_vidSetPinValue(0, 1, 1);
//	ElectricHeater_init();



		__asm__ __volatile__ ("sei" ::);
	DIO_vidSetPinDirection(DIO_GROUP_A, DIO_PIN_1, DIO_OUTPUT);
	EXTI_vidInit();
	EXTI_vidSetSenseLevel(EXTI_INT_0 , EXTI_RISING);
	EXTI_vidSetCallBack(callback, EXTI_INT_0);
	EXTI_vidEnableInterrupt(EXTI_INT_0);

	while(1){

	}

	return 0;

}

void callback(void){
	EXTI_vidDisableInterrupt(EXTI_INT_0);
	_delay_ms(100);
	DIO_vidTogglePinValue(DIO_GROUP_A, DIO_PIN_1);
	EXTI_vidEnableInterrupt(EXTI_INT_0);
}
*/
