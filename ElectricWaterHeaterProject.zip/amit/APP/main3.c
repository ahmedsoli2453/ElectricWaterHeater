/*
 * main3.c
 *
 *  Created on: Sep 11, 2023
 *      Author: ahmed
 */
/*
 * main.c
 *
 *  Created on: Nov 1, 2019
 *      Author: hp
 */

#include "../Lib/stdTypes.h"
#include "../MCAL/DIO/DIO_int.h"
#include "../MCAL/EXTI/EXTI_int.h"
#include "../FreeRTOS/AVR_REG.h"
#include "../FreeRTOS/FreeRTOS.h"
#include "../FreeRTOS/task.h"

#include "../FreeRTOS/BIT_MATH.h"


//#include "../FreeRTOS/LCD_int.h"
//#include <util/delay.h>
/*static u8 status_here = 255;
void Blink_LED1 (void*pv);
void Blink_LED2 (void*pv);
void callback_ON(void);


int main(){

	//status_here = 0;
	DIO_vidSetPinDirection (DIO_GROUP_A , DIO_PIN_1 , DIO_OUTPUT);
	DIO_vidSetPinDirection (DIO_GROUP_A , DIO_PIN_2 , DIO_OUTPUT);
	DIO_vidSetPinDirection (DIO_GROUP_A , DIO_PIN_3 , DIO_OUTPUT);


	EXTI_vidInit();
	EXTI_vidSetCallBack(callback_ON, EXTI_INT_0);
	EXTI_vidSetSenseLevel(EXTI_INT_0 ,EXTI_RISING);
	EXTI_vidEnableInterrupt(EXTI_INT_0);
	//DDRD = 0x03;
	//LCD_voidInt();
	xTaskCreate(Blink_LED1,NULL,configMINIMAL_STACK_SIZE,NULL,2,NULL);
	xTaskCreate(Blink_LED2,NULL,configMINIMAL_STACK_SIZE,NULL,2,NULL);
	DIO_vidSetPinValue(DIO_GROUP_A , DIO_PIN_3 , DIO_LOW);
	//status_here = 0;
	vTaskStartScheduler();

	return 0;
}

void Blink_LED1 (void*pv)
{
	while (1)
	{
		if(status_here==0){
				vTaskDelay(1500);
			}
		else{
		//LCD_voidGoToPosition(1,1);
		//LCD_voidSendString("IAmTASK1");
		DIO_vidSetPinValue(DIO_GROUP_A , DIO_PIN_2 , DIO_HIGH);
		vTaskDelay(1000);
		DIO_vidSetPinValue(DIO_GROUP_A , DIO_PIN_2 , DIO_LOW);
		vTaskDelay(1000);
	}
}
}

void Blink_LED2 (void*pv)
{
	while (1)
	{
		if(status_here==0){
			vTaskDelay(1500);
		}
		else{
		//LCD_voidGoToPosition(1,1);
		//LCD_voidSendString("IAmTASK2");
		DIO_vidSetPinValue(DIO_GROUP_A , DIO_PIN_1 , DIO_HIGH);
		vTaskDelay(1500);
		DIO_vidSetPinValue(DIO_GROUP_A , DIO_PIN_1 , DIO_LOW);
		vTaskDelay(1500);
	}
}
}
void callback_ON(void){
	if(status_here == 0){
		status_here = 1;
	}
	else{
		status_here =0;
	}
	//DIO_vidTogglePinValue(DIO_GROUP_A , DIO_PIN_3);
}

*/
