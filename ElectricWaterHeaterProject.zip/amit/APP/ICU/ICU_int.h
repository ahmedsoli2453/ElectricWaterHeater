/*
 * ICU_int.h
 *
 *  Created on: Aug 4, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef APP_ICU_ICU_INT_H_
#define APP_ICU_ICU_INT_H_

typedef enum
{
    _1st_RISING,
    _FALLING,
    _2nd_RISING,
    _Caluclation,
    _IDLE
}_enuICUState;

void ICU_vidInit(void);

void ICU_vidExecuteStateMachine (void);

void ICU_vidResetStateMachine(void);
u8 ICU_u8GetDutyCycle(void);

u16 ICU_u8GetFrequency(void);

_enuICUState ICU_enuGetCurrentState(void);

#endif /* APP_ICU_ICU_INT_H_ */
