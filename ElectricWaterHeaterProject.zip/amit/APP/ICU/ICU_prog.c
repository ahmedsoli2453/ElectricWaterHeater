/*
 * ICU_prog.c
 *
 *  Created on: Aug 4, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../../Lib/stdTypes.h"

#include "../../MCAL/DIO/DIO_int.h"
#include "../../MCAL/Timer0/Timer0_int.h"
#include "../../MCAL/EXTI/EXTI_int.h"

#include "ICU_int.h"

static _enuICUState ICU_enuStateMachine = _1st_RISING;
static u8 ICU_u8FlagOnEXTI = 0;

static u8 ICU_u8OnTime =0 ;
static u8 ICU_u8CycleTime=0 ;

static u8 ICU_u8OnTimeOVF =0 ;
static u8 ICU_u8CycleTimeOVF =0 ;

static u8 ICU_u8DutyCycle =0;
static u16 ICU_u16Freqency =0;
static u16 ICU_u16OVFCounts= 0;

static void vidSetFlagOnEXTI(void);
static void vidCounterOfOVF(void);


void ICU_vidInit(void)
{
	DIO_vidSetPinDirection(DIO_GROUP_D, DIO_PIN_2, DIO_INPUT);
	DIO_vidSetPinValue(DIO_GROUP_D, DIO_PIN_2, DIO_FLOAT);
    Timer0_vidInit();
    EXTI_vidInit();
    EXTI_vidSetCallBack(vidSetFlagOnEXTI,EXTI_INT_0);
    Timer_vidCallBack(vidCounterOfOVF);
}


void ICU_vidResetStateMachine(void)
{
    ICU_enuStateMachine = _1st_RISING;
    ICU_u8FlagOnEXTI = 0;
    ICU_u8OnTime =0 ;
    ICU_u8CycleTime=0 ;
    ICU_u8OnTimeOVF =0 ;
    ICU_u8CycleTimeOVF =0 ;
    ICU_u8DutyCycle =0;
    ICU_u16Freqency =0;
    ICU_u16OVFCounts= 0;
    EXTI_vidSetSenseLevel(EXTI_INT_0 , EXTI_RISING);
    EXTI_vidEnableInterrupt(EXTI_INT_0);
    Timer_vidEnableInterrupt();
}
void ICU_vidExecuteStateMachine (void)
{
    switch (ICU_enuStateMachine)
    {
    case _1st_RISING:
        if (ICU_u8FlagOnEXTI == 1)
        {
            Timer_vidSetTimerCounts(0);
            ICU_u16OVFCounts =0;
            EXTI_vidSetSenseLevel(EXTI_INT_0 , EXTI_FALLING);
            ICU_u8FlagOnEXTI = 0;
            ICU_enuStateMachine = _FALLING;
        }
        break;

    case _FALLING:
        if (ICU_u8FlagOnEXTI == 1)
        {
            ICU_u8OnTime = Timer_u8GetTimerCounts();
            ICU_u8OnTimeOVF = ICU_u16OVFCounts;
            EXTI_vidSetSenseLevel(EXTI_INT_0 , EXTI_RISING);
            ICU_u8FlagOnEXTI = 0;
            ICU_enuStateMachine = _2nd_RISING;
        } 
        break;
    case _2nd_RISING:
        if (ICU_u8FlagOnEXTI == 1)
        {
            ICU_u8CycleTime = Timer_u8GetTimerCounts();
            ICU_u8CycleTimeOVF = ICU_u16OVFCounts;
            EXTI_vidDisableInterrupt(EXTI_INT_0);
            Timer_vidDisableInterrupt();
            ICU_u8FlagOnEXTI = 0;
            ICU_enuStateMachine = _Caluclation;
        }
        break;
    case _Caluclation:
        ICU_u8DutyCycle = ((ICU_u8OnTime + ICU_u8OnTimeOVF *256ul)* 100)/(ICU_u8CycleTime + ICU_u8CycleTimeOVF * 256ul);
        ICU_u16Freqency = (16000000ULL)/((ICU_u8CycleTime + ICU_u8CycleTimeOVF*256ul)* 8ul);
        
        ICU_enuStateMachine = _IDLE;
        break;
    
    default:
        break;
    }
}

u8 ICU_u8GetDutyCycle(void)
{
    return ICU_u8DutyCycle;
}

u16 ICU_u8GetFrequency(void)
{
    return ICU_u16Freqency;
}

_enuICUState ICU_enuGetCurrentState(void)
{
    return ICU_enuStateMachine;
}

static void vidSetFlagOnEXTI(void)
{
    ICU_u8FlagOnEXTI = 1;
}

static void vidCounterOfOVF(void)
{
    ICU_u16OVFCounts++;
}
