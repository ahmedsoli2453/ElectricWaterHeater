/*
 * Login_config.h
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef APP_LOGIN_SYSTEM_LOGIN_CONFIG_H_
#define APP_LOGIN_SYSTEM_LOGIN_CONFIG_H_

#define LOGIN_PASSWORD      "C15x3"

#endif /* APP_LOGIN_SYSTEM_LOGIN_CONFIG_H_ */
