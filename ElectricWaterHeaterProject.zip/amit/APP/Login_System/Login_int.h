/*
 * Loging_int.h
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef APP_LOGIN_SYSTEM_LOGING_INT_H_
#define APP_LOGIN_SYSTEM_LOGING_INT_H_

void Login_vidInit(void);
void Login_vidWelcome(void);
void Login_vidEnterPassword(void);
void Login_vidCheckPassword(void);
u8 Login_GetCompareFlag(void);

#endif /* APP_LOGIN_SYSTEM_LOGING_INT_H_ */
