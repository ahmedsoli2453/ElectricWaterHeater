/*
 * Login_prog.c
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../../Lib/stdTypes.h"

#include "../../HAL/Keypad/Keypad_int.h"
#include "../../HAL/LCD/LCD_int.h"

#include <util/delay.h>

#include "Login_config.h"

static char Login_acEnteredPassword[6] = {0};
static u8 Login_u8CompareFlag = 3;

void Login_vidInit(void)
{
    LCD_enuInit();
    Keypad_vidInit();
}


void Login_vidWelcome(void)
{
    LCD_vidSendCommand(0x01);
    LCD_vidSendCommand(0x84);
    LCD_vidWriteString("Welcome");
    _delay_ms(1000);
}

void Login_vidEnterPassword(void)
{
    u8 Local_u8KeyPressed = 0 ;
    s8 Local_s8Counter = 0;
    LCD_vidSendCommand(0x01);
    LCD_vidSendCommand(0x80);
    LCD_vidWriteString("Enter Password:");
    LCD_vidSendCommand(0xC0);
    
    for (u8 i =0; i<6; i++)
    {
        Login_acEnteredPassword[i]=0;
    }
    while ((Local_u8KeyPressed != '=') && (Local_s8Counter < 6))
    {
        Local_u8KeyPressed = Keypad_u8GetPressedKey();
        if ((Local_u8KeyPressed != KEYPAD_NOT_PRESSED) && (Local_u8KeyPressed != '='))
        {
            Login_acEnteredPassword[Local_s8Counter] = Local_u8KeyPressed;
            Local_s8Counter++;
            LCD_vidSendData('*');
        }
    }
}

void Login_vidCheckPassword(void)
{
    char * Local_pcHardCodePass = LOGIN_PASSWORD;
    for (u8 i =0; i<6; i++)
    {
        if (Login_acEnteredPassword[i] !=  Local_pcHardCodePass[i])
        {
            Login_u8CompareFlag = 1;
            break;
        }
        else
        {
            Login_u8CompareFlag = 0;
        }
    }
    if (Login_u8CompareFlag == 0 )
    {
        LCD_vidSendCommand(0x01);
        LCD_vidSendCommand(0x80);
        LCD_vidWriteString("Successful Login");
        _delay_ms(1000);
    }
    else
    {
        LCD_vidSendCommand(0x01);
        LCD_vidSendCommand(0x81);
        LCD_vidWriteString("Wrong Password");
        LCD_vidSendCommand(0xC2);
        LCD_vidWriteString("Try Again!!!");
        _delay_ms(1000);
    }
}
 
u8 Login_GetCompareFlag(void)
{
    return Login_u8CompareFlag;
}