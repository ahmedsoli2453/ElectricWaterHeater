/*
 * Timer2_prog.c
 *
 *  Created on: Sep 7, 2023
 *      Author: ahmed
 */

#include "Timer2_int.h"
#include "Timer2_priv.h"

//static void (*Timer2_pfunOvfISRFun)(void)= NULL;
static void (*Timer_pfunCallBack)(void)= NULL;
//static u16 Timer2_u16OvfCounts;
//static u8 Timer2_u8Preload;
//static u16 Timer2_u16ISRCounter;
//static u8 Timer2_u8CTCValue;


void Timer2_vidInit(void){
	TCNT2 = 0;
#if TIMER2_PRESCALER == 0
    TCCR2 &=~(7<<0);
    //#warning timer2 has been stopped by 0 prescaler
	#elif TIMER2_PRESCALER == 8
		TCCR2 &=~(7<<0);
		TCCR2 |= (2<<0);
#elif TIMER2_PRESCALER == 1024
    TCCR2 &=~(7<<0);
    TCCR2 |= (5<<0);
#endif

#if TIMER2_MODE ==  TIMER2_OVF
    TCCR2 &= ~(9<<3);
#elif TIMER2_MODE == TIMER2_CTC
    TCCR2 &=~(1<<6);
    TCCR2 |= (1<<3);
#endif


}

void Timer2_vidCallBack(void (*Copy_pfunCallBack)(void)){
	  if (Copy_pfunCallBack != NULL)
	   {
	       Timer_pfunCallBack = Copy_pfunCallBack;
	   }

}

void Timer2_vidEnableOInterrupt(void){
	TIMSK |=(1<<6);
}

void Timer2_vidDisableOInterrupt(void){
	TIMSK &=~(1<<6);

}
void setTimer2Value(u8 value){
	TCNT2 = value;
}

void __vector_5 (void)__attribute__((signal));
void __vector_5 (void)
{
   if (Timer_pfunCallBack != NULL)
   {
       Timer_pfunCallBack();
   }
}

