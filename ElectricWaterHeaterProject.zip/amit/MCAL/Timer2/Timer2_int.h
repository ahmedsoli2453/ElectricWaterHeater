/*
 * Timer2_int.h
 *
 *  Created on: Sep 1, 2023
 *      Author: ahmed
 */

#ifndef MCAL_TIMER2_TIMER2_INT_H_
#define MCAL_TIMER2_TIMER2_INT_H_

#include "../../Lib/stdTypes.h"
void Timer2_vidInit(void);

//void Timer2_vidSetAschDelay(u32 Copy_u32MilliSecond , void (*Copy_pfunAppFun)(void));

//void Timer2_vidSetSychDelay(u32 Copy_u32MilliSecond);

//void Timer2_vidSetCompareCount(u8 Copy_u8CTCValue);

//u8 Timer2_u8GetTimerCounts(void);

//void Timer2_vidSetTimerCounts(u8 Copy_u8Counts);

void Timer2_vidCallBack(void (*Copy_pfunCallBack)(void));

void Timer2_vidEnableOInterrupt(void);

void Timer2_vidDisableOInterrupt(void);

void setTimer2Value(u8 value);


#endif /* MCAL_TIMER2_TIMER2_INT_H_ */
