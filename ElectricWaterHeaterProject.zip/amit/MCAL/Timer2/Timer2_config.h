/*
 * Timer2_config.h
 *
 *  Created on: Sep 7, 2023
 *      Author: ahmed
 */

#ifndef MCAL_TIMER2_TIMER2_CONFIG_H_
#define MCAL_TIMER2_TIMER2_CONFIG_H_

#define TIMER2_PRESCALER         1024

#define TIMER2_MODE             TIMER2_OVF

#define TIMER2_INTERRUPT_MODE   TIMER2_INTERRUPT

#define TIMER2_OC2_OUT          OC2_DISCONNECTED


#endif /* MCAL_TIMER2_TIMER2_CONFIG_H_ */
