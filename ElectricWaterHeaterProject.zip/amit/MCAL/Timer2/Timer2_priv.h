/*
 * Timer2_priv.h
 *
 *  Created on: Sep 1, 2023
 *      Author: ahmed
 */

#ifndef MCAL_TIMER2_TIMER2_PRIV_H_
#define MCAL_TIMER2_TIMER2_PRIV_H_

#define TCCR2               *((u8*)0x45)
#define TCNT2               *((u8*)0x44)
#define OCR2                *((u8*)0x43)
#define TIMSK               *((u8*)0x59)
#define TIFR                *((u8*)0x58)

#define TIMER2_OVF          98
#define TIMER2_CTC          45

#define TIMER2_INTERRUPT        32
#define TIMER2_POLLING          39

#define OC2_DISCONNECTED            21
#define OC2_TOGGLING                65
#define OC2_CLEARING                26
#define OC2_SETTING                 10


#endif /* MCAL_TIMER2_TIMER2_PRIV_H_ */
