/*
 * EXTI_int.h
 *
 *  Created on: Jul 8, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_EXTI_EXTI_INT_H_
#define MCAL_EXTI_EXTI_INT_H_

void EXTI_vidInit(void);

void EXTI_vidSetSenseLevel(u8 Copy_u8IntPinID , u8 Copy_u8SenseLevel);

void EXTI_vidEnableInterrupt(u8 Copy_u8IntPinID);

void EXTI_vidDisableInterrupt(u8 Copy_u8IntPinID);

void EXTI_vidSetCallBack(void (*Copy_pfunAppFun)(void), u8 Copy_u8IntPinID);

#define EXTI_INT_0      0
#define EXTI_INT_1      1
#define EXTI_INT_2      2

#define EXTI_LOW_LEVEL          4
#define EXTI_ANY_CHANGE         32
#define EXTI_FALLING            76
#define EXTI_RISING             98

#endif /* MCAL_EXTI_EXTI_INT_H_ */
