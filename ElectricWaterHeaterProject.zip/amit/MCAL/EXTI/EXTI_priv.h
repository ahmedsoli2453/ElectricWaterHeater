/*
 * EXTI_priv.h
 *
 *  Created on: Jul 8, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_EXTI_EXTI_PRIV_H_
#define MCAL_EXTI_EXTI_PRIV_H_

#define MCUCR           *((u8*)0x55)
#define MCUCSR          *((u8*)0x54)
#define GICR            *((u8*)0x5B)
#define GIFR            *((u8*)0x5A)


#define EXTI_INT_0      0
#define EXTI_INT_1      1
#define EXTI_INT_2      2

#define EXTI_LOW_LEVEL          4
#define EXTI_ANY_CHANGE         32
#define EXTI_FALLING            76
#define EXTI_RISING             98

#endif /* MCAL_EXTI_EXTI_PRIV_H_ */
