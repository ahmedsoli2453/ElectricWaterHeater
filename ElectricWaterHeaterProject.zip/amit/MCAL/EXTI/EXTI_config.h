/*
 * EXTI_config.h
 *
 *  Created on: Jul 8, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_EXTI_EXTI_CONFIG_H_
#define MCAL_EXTI_EXTI_CONFIG_H_

#define EXTI_INIT_INT_PIN       EXTI_INT_0          
#define EXTI_INIT_LEVEL         EXTI_RISING          


#endif /* MCAL_EXTI_EXTI_CONFIG_H_ */
