/*
 * EXTI_prog.c
 *
 *  Created on: Jul 8, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../../Lib/stdTypes.h"

#include "EXTI_config.h"
#include "EXTI_priv.h"

static void (*EXTI_pfunISR0Fun)(void) =NULL;
static void (*EXTI_pfunISR1Fun)(void) =NULL;
static void (*EXTI_pfunISR2Fun)(void) =NULL;



void EXTI_vidInit(void)
{
    #if EXTI_INIT_INT_PIN == EXTI_INT_0
        GICR |= (1<<6);
        MCUCR &= ~(3<<0);
        #if EXTI_INIT_LEVEL == EXTI_LOW_LEVEL

        #elif EXTI_INIT_LEVEL == EXTI_ANY_CHANGE
            MCUCR |= (1<<0);
        #elif EXTI_INIT_LEVEL == EXTI_FALLING
            MCUCR |= (1<<1);
        #elif EXTI_INIT_LEVEL == EXTI_RISING
            MCUCR |= (3<<0);
        #else
        #error sense level of EXTI0 is wrong
        #endif

    #elif EXTI_INIT_INT_PIN == EXTI_INT_1
        GICR |= (1<<7);
        MCUCR &= ~(3<<2);
        #if EXTI_INIT_LEVEL == EXTI_LOW_LEVEL

        #elif EXTI_INIT_LEVEL == EXTI_ANY_CHANGE
            MCUCR |= (1<<2);
        #elif EXTI_INIT_LEVEL == EXTI_FALLING
            MCUCR |= (1<<3);
        #elif EXTI_INIT_LEVEL == EXTI_RISING
            MCUCR |= (3<<2);
        #else
        #error sense level of EXTI1 is wrong
        #endif
    #elif EXTI_INIT_INT_PIN == EXTI_INT_2
        GICR |= (1<<5);
        MCUCSR &= ~(1<<6);
        #if EXTI_INIT_LEVEL == EXTI_FALLING

        #elif EXTI_INIT_LEVEL == EXTI_RISING
            MCUCSR |= (1<<6);
        #else
        #error sense level of EXTI2 is wrong
        #endif
    #else
    #error EXTI configuration is wrong
    #endif
}

void EXTI_vidSetSenseLevel(u8 Copy_u8IntPinID , u8 Copy_u8SenseLevel)
{
    if (Copy_u8IntPinID == EXTI_INT_0)
    {
        MCUCR &=~(3<<0);
        switch (Copy_u8SenseLevel)
        {
        case EXTI_LOW_LEVEL:
            break;
        case EXTI_ANY_CHANGE:
            MCUCR |= (1<<0);
            break;
        case EXTI_FALLING:
            MCUCR |= (1<<1);
            break;
        case EXTI_RISING:
            MCUCR |= (3<<0);
            break;
        default:
            break;
        }
    }
    else if (Copy_u8IntPinID == EXTI_INT_1)
    {
        MCUCR &=~(3<<2);
        switch (Copy_u8SenseLevel)
        {
        case EXTI_LOW_LEVEL:
            break;
        case EXTI_ANY_CHANGE:
            MCUCR |= (1<<2);
            break;
        case EXTI_FALLING:
            MCUCR |= (1<<3);
            break;
        case EXTI_RISING:
            MCUCR |= (3<<2);
            break;
        default:
            break;
        }

    }
    else if (Copy_u8IntPinID == EXTI_INT_2)
    {
        MCUCSR &=~(1<<6);
        switch (Copy_u8SenseLevel)
        {
        case EXTI_FALLING:

            break;
        case EXTI_RISING:
            MCUCR |= (1<<6);
            break;
        default:
            break;
        }

    }
    else
    {
    }
}

void EXTI_vidEnableInterrupt(u8 Copy_u8IntPinID)
{
    if (Copy_u8IntPinID == EXTI_INT_0)
    {
        GICR |= (1<<6);
    }
    else if (Copy_u8IntPinID == EXTI_INT_1)
    {
        GICR |= (1<<7);
    }
    else if (Copy_u8IntPinID == EXTI_INT_2)
    {
        GICR |= (1<<5);
    }
    else
    {
    }
}
void EXTI_vidDisableInterrupt(u8 Copy_u8IntPinID)
{
    if (Copy_u8IntPinID == EXTI_INT_0)
    {
        GICR &=~(1<<6);
    }
    else if (Copy_u8IntPinID == EXTI_INT_1)
    {
        GICR &=~(1<<7);
    }
    else if (Copy_u8IntPinID == EXTI_INT_2)
    {
        GICR &=~(1<<5);
    }
    else
    {
    }

}

void EXTI_vidSetCallBack(void (*Copy_pfunAppFun)(void), u8 Copy_u8IntPinID)
{
    if (Copy_pfunAppFun != NULL)
    {
        if (Copy_u8IntPinID == EXTI_INT_0)
        {
            EXTI_pfunISR0Fun = Copy_pfunAppFun;
        }
        else if (Copy_u8IntPinID == EXTI_INT_1)
        {
            EXTI_pfunISR1Fun = Copy_pfunAppFun;
        }
        if (Copy_u8IntPinID == EXTI_INT_2)
        {
            EXTI_pfunISR2Fun = Copy_pfunAppFun;
        }
    }
}



void __vector_1(void)__attribute__((signal));
void __vector_2(void)__attribute__((signal));
void __vector_3(void)__attribute__((signal));
//INT0
void __vector_1(void)
{
    if (EXTI_pfunISR0Fun != NULL)
    {
        EXTI_pfunISR0Fun ( );
    }
}
//INT1
void __vector_2(void)
{
    if (EXTI_pfunISR1Fun != NULL)
    {
        EXTI_pfunISR1Fun ( );
    }

}
//INT2
void __vector_3(void)
{
    if (EXTI_pfunISR2Fun != NULL)
    {
        EXTI_pfunISR2Fun ( );
    }

}
