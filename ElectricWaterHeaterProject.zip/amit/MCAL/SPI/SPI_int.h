/*
 * SPI_int.h
 *
 *  Created on: Oct 29, 2021
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef SPI_INT_H_
#define SPI_INT_H_

void SPI_vidInit(void);

u8 SPI_u8Transcieve(u8 Copy_u8Data);

#endif /* SPI_INT_H_ */
