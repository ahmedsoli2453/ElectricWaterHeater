/*
 * PWM_prog.c
 *
 *  Created on: May 26, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../../Lib/stdTypes.h"


#include "PWM_config.h"
#include "PWM_priv.h"


void PWM_vidInit(void)
{

}

void PWM_vidSetDutyNFreq(u8 Copy_u8DutyCycle , u16 Copy_u16Frequency)
{

}

void PWM_vidStopPWM(void)
{
    
}

