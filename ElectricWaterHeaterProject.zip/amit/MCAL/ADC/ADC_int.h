/*
 * ADC_int.h
 *
 *  Created on: Jul 15, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_ADC_ADC_INT_H_
#define MCAL_ADC_ADC_INT_H_

void ADC_vidInit(void);

u8 ADC_u8ReadPolling(u8 Copy_u8Channel);

u16 ADC_u16ReadPolling(u8 Copy_u8Channel);

void ADC_vidStartConversion(void);


u16 ADC_u16Read(void);

void ADC_vidSelectChannel(u8 Copy_u8Channel);

void ADC_vidAutoTriggerEnable(u8 Copy_u8TriggerSource);

void ADC_vidAutoTriggerDisable(void);

void ADC_vidInteruptEnable(void);

void ADC_vidInteruptDisable(void);

void ADC_vidSetCallBack(void (*Copy_pfunAppFun));


#endif /* MCAL_ADC_ADC_INT_H_ */
