/*
 * ADC_config.h
 *
 *  Created on: Jul 15, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_ADC_ADC_CONFIG_H_
#define MCAL_ADC_ADC_CONFIG_H_
                // 2 ,4,8 ,....
#define ADC_PRES    
                // left or right    
#define ADC_ADJUMENT        
                // volt reference
#define ADC_REFERENCE        
                // init channel at beginning
#define ADC_INIT_CHNL        
                // trigger en(source) , trigger dis
#define ADC_TRIGGER_STATE        
                // Polling , Interrupt
#define ADC_STATUS        


#endif /* MCAL_ADC_ADC_CONFIG_H_ */
