/*
 * ADC_prog.c
 *
 *  Created on: Jul 15, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#include "../../Lib/stdTypes.h"


#include "ADC_config.h"
#include "ADC_priv.h"

void ADC_vidInit(void)
{
    // AVCC ref , left , channel 1 single ended
    ADMUX  = 0b01000000;
    // en ADC , dis PIE - auto trigger , 64 prescaler
    ADCSRA = 0b10000110;
}

u8 ADC_u8ReadPolling(u8 Copy_u8Channel)
{
    if (Copy_u8Channel <= 31)
    {
        ADMUX &= ~0x1F;
        ADMUX |= Copy_u8Channel;
        // start conversion
        ADCSRA |= (1<<6);
        while (((ADCSRA >>4)&1) == 0 );
    }
    return ADCH;
}
u16 ADC_u16ReadPolling(u8 Copy_u8Channel){
	u16 data;
	if (Copy_u8Channel <= 31)
	    {
	        ADMUX &= ~0x1F;
	        ADMUX |= Copy_u8Channel;
	        // start conversion
	        ADCSRA |= (1<<6);
	        while (((ADCSRA >>4)&1) == 0 );
	    }
	data = (u16)ADCH;
	data = (data<<2)|(ADCL>>6);
	    return data;
}

void ADC_vidStartConversion(void){
	ADCSRA |= (1 << 6);
}

//u16 ADC_u16Read(void);

//void ADC_vidSelectChannel(u8 Copy_u8Channel);

//void ADC_vidAutoTriggerEnable(u8 Copy_u8TriggerSource);

//void ADC_vidSetCallBack(void (*Copy_pfunAppFun));
