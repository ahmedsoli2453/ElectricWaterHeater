/*
 * ADC_priv.h
 *
 *  Created on: Jul 15, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef MCAL_ADC_ADC_PRIV_H_
#define MCAL_ADC_ADC_PRIV_H_

#define ADMUX               *((u8*)0x27)
#define ADCSRA              *((u8*)0x26)

#define ADCL                *((u8*)0x24)
#define ADCH                *((u8*)0x25)
#define SFIOR               *((u8*)0x50)


//#define ADMUX               *((u8*)0x07)
//#define ADCSRA              *((u8*)0x06)
//#define ADCL                *((u8*)0x04)
//#define ADCH                *((u8*)0x05)
//#define SFIOR               *((u8*)0x30)


#endif /* MCAL_ADC_ADC_PRIV_H_ */
