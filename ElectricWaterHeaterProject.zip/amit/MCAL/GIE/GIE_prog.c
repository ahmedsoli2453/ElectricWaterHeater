/*
 * GIE_prog.c
 *
 *  Created on: Jul 8, 2023
 *      Author: Ahmed El-Gaafrawy
 */


void GIE_vidEnable(void)
{
	__asm__("SEI");
//	asm("SEI");
//	__asm("SEI");
}

void GIE_vidDisable(void)
{
	__asm__("CLI");
}
