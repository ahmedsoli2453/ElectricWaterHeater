/*
 * UART_int.h
 *
 *  Created on: Sep 27, 2021
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef UART_INT_H_
#define UART_INT_H_

void UART_vidInit(void);

void UART_vidSendChar(u8 Copy_u8Data);

u8 UART_u8RecieveChar(void);

void UART_vidSendString(const char* Copy_pcData);

void UART_vidRecieveString(char * Copy_pcData);

#endif /* UART_INT_H_ */
