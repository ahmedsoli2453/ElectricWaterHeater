/*
 * EEPROM_priv.h
 *
 *  Created on: Aug 30, 2023
 *      Author: ahmed
 */

#ifndef MCAL_EEPROM_EEPROM_PRIV_H_
#define MCAL_EEPROM_EEPROM_PRIV_H_



#define EEARL	*((u8*)0x3E)
#define EEARH   *((u8*)0x3F)
#define EEDR    *((u8*)0x3D)
#define EECR    *((u8*)0x3C)
#define EERE    0
#define EEWE    1
#define EEMWE   2
#define EERIE   3
#endif /* MCAL_EEPROM_EEPROM_PRIV_H_ */
