/*
 * EEPROM_prog.c
 *
 *  Created on: Aug 30, 2023
 *      Author: ahmed
 */


#include "EEPROM_priv.h"
#include "EEPROM_int.h"
#include "EEPROM_config.h"
#include "../../Lib/stdTypes.h"


void EEPROM_write(u16 uiAddress, u8 ucData)
{
/* Wait for completion of previous write */
while(EECR & (1<<EEWE))
;
/* Set up address and data registers */
EEARL = uiAddress & 0xFF;
EEARH |= uiAddress>>8;
EEDR = ucData;
/* Write logical one to EEMWE */
EECR |= (1<<EEMWE);
/* Start eeprom write by setting EEWE */
EECR |= (1<<EEWE);
}

u8 EEPROM_read(u16 uiAddress)
{
/* Wait for completion of previous write */
while(EECR & (1<<EEWE))
;
/* Set up address register */
EEARL = uiAddress & 0xFF;
EEARH |= uiAddress>>8;
/* Start eeprom read by writing EERE */
EECR |= (1<<EERE);
/* Return data from data register */
return EEDR;
}
