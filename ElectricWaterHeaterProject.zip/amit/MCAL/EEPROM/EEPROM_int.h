/*
 * EEPROM_int.h
 *
 *  Created on: Aug 30, 2023
 *      Author: ahmed
 */

#ifndef MCAL_EEPROM_EEPROM_INT_H_
#define MCAL_EEPROM_EEPROM_INT_H_

#include "../../Lib/stdTypes.h"



void EEPROM_write(u16 uiAddress, u8 ucData);
u8 EEPROM_read(u16 uiAddress);


#endif /* MCAL_EEPROM_EEPROM_INT_H_ */
