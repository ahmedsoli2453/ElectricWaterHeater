/*
 * SegmentsEnable_prog.c
 *
 *  Created on: Sep 9, 2023
 *      Author: ahmed
 */
#include "../../Lib/stdTypes.h"
#include "../../MCAL/DIO/DIO_int.h"
#include "SegmentsEnable_config.h"


void segment_init(){
	DIO_vidSetPinDirection(SEGMENT_1_GROUP,SEGMENT_1_PIN, DIO_OUTPUT);
	DIO_vidSetPinDirection(SEGMENT_2_GROUP,SEGMENT_2_PIN, DIO_OUTPUT);
}
void enable_segment(u8 segment_id){
	DIO_vidSetPinValue(SEGMENT_1_GROUP,segment_id-1+SEGMENT_1_PIN, 1);
}

void disable_segment(u8 segment_id){
	DIO_vidSetPinValue(SEGMENT_1_GROUP,segment_id-1+SEGMENT_1_PIN, 0);
}
