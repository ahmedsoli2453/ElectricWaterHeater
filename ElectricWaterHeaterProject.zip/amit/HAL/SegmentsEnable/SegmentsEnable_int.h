/*
 * SegmentsEnable_int.h
 *
 *  Created on: Sep 9, 2023
 *      Author: ahmed
 */

#ifndef HAL_SEGMENTSENABLE_SEGMENTSENABLE_INT_H_
#define HAL_SEGMENTSENABLE_SEGMENTSENABLE_INT_H_

void segment_init();
void enable_segment(u8 segment_id);
void disable_segment(u8 segment_id);

#endif /* HAL_SEGMENTSENABLE_SEGMENTSENABLE_INT_H_ */
