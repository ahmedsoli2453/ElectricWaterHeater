/*
 * HexaDecoder_config.h
 *
 *  Created on: Jun 9, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef HEXADECODER_CONFIG_H_
#define HEXADECODER_CONFIG_H_

#define ENABLE_SSG1_GRP             DIO_GROUP_B
#define ENABLE_SSG1_PIN             DIO_PIN_6

#define ENABLE_SSG2_GRP             DIO_GROUP_B
#define ENABLE_SSG2_PIN             DIO_PIN_7

#define PIN_A_GRP             DIO_GROUP_A
#define PIN_A_PIN             DIO_PIN_4

#define PIN_B_GRP             DIO_GROUP_A
#define PIN_B_PIN             DIO_PIN_5

#define PIN_C_GRP             DIO_GROUP_A
#define PIN_C_PIN             DIO_PIN_6

#define PIN_D_GRP             DIO_GROUP_A
#define PIN_D_PIN             DIO_PIN_7

#define PIN_A2_GRP             DIO_GROUP_C
#define PIN_A2_PIN             DIO_PIN_0

#define PIN_B2_GRP             DIO_GROUP_C
#define PIN_B2_PIN             DIO_PIN_1

#define PIN_C2_GRP             DIO_GROUP_C
#define PIN_C2_PIN             DIO_PIN_2

#define PIN_D2_GRP             DIO_GROUP_C
#define PIN_D2_PIN             DIO_PIN_3


#endif /* HEXADECODER_CONFIG_H_ */
