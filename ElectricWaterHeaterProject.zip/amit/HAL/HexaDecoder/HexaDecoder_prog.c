/*
 * HexaDecoder_prog.c
 *
 *  Created on: Jun 9, 2023
 *      Author: Ahmed El-Gaafrawy
 */
// include public libraries
#include "../../Lib/stdTypes.h"

//include dependencies lower layer libraries
#include "../../MCAL/DIO/DIO_int.h"

//my own libraries
#include "HexaDecoder_config.h"
#include "HexaDecoder_priv.h"


void HexaDecoder_vidInit(void)
{
    DIO_vidSetPinDirection(ENABLE_SSG1_GRP, ENABLE_SSG1_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(ENABLE_SSG2_GRP, ENABLE_SSG2_PIN, DIO_OUTPUT);

    DIO_vidSetPinDirection(PIN_A_GRP, PIN_A_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(PIN_B_GRP, PIN_B_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(PIN_C_GRP, PIN_C_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(PIN_D_GRP, PIN_D_PIN, DIO_OUTPUT);
}

void HexaDecoder_vidDisplayNum(u8 Copy_u8Num)
{
    if (Copy_u8Num <= 9)
    {
        DIO_vidSetPinValue(PIN_A_GRP, PIN_A_PIN, ((Copy_u8Num >> 0) &1));
        DIO_vidSetPinValue(PIN_B_GRP, PIN_B_PIN, ((Copy_u8Num >> 1) &1));
        DIO_vidSetPinValue(PIN_C_GRP, PIN_C_PIN, ((Copy_u8Num >> 2) &1));
        DIO_vidSetPinValue(PIN_D_GRP, PIN_D_PIN, ((Copy_u8Num >> 3) &1));
    }
}

void HexaDecoder_vidDisplayNum2(u8 Copy_u8Num){
	if (Copy_u8Num <= 9)
	    {
	        DIO_vidSetPinValue(PIN_A2_GRP, PIN_A2_PIN, ((Copy_u8Num >> 0) &1));
	        DIO_vidSetPinValue(PIN_B2_GRP, PIN_B2_PIN, ((Copy_u8Num >> 1) &1));
	        DIO_vidSetPinValue(PIN_C2_GRP, PIN_C2_PIN, ((Copy_u8Num >> 2) &1));
	        DIO_vidSetPinValue(PIN_D2_GRP, PIN_D2_PIN, ((Copy_u8Num >> 3) &1));
	    }

}

void HexaDecoder_vidEnable(u8 Copy_u8SSG_ID)
{
    if (Copy_u8SSG_ID == SSG_ID_1)
    {
        DIO_vidSetPinValue(ENABLE_SSG1_GRP, ENABLE_SSG1_PIN, DIO_HIGH);
    }
    else if (Copy_u8SSG_ID == SSG_ID_2)
    {
        DIO_vidSetPinValue(ENABLE_SSG2_GRP, ENABLE_SSG2_PIN, DIO_HIGH);
    }
}

void HexaDecoder_vidDisable(u8 Copy_u8SSG_ID)
{
    if (Copy_u8SSG_ID == SSG_ID_1)
    {
        DIO_vidSetPinValue(ENABLE_SSG1_GRP, ENABLE_SSG1_PIN, DIO_LOW);
    }
    else if (Copy_u8SSG_ID == SSG_ID_2)
    {
        DIO_vidSetPinValue(ENABLE_SSG2_GRP, ENABLE_SSG2_PIN, DIO_LOW);
    }
}
