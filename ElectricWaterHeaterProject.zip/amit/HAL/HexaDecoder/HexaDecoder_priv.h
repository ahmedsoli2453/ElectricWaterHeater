/*
 * HexaDecoder_priv.h
 *
 *  Created on: Jun 9, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef HEXADECODER_PRIV_H_
#define HEXADECODER_PRIV_H_

#define SSG_ID_1 8
#define SSG_ID_2 21

#endif /* HEXADECODER_PRIV_H_ */
