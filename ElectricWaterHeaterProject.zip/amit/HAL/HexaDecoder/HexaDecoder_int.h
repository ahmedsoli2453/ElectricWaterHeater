/*
 * HexaDecoder_int.h
 *
 *  Created on: Jun 9, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef HEXADECODER_INT_H_
#define HEXADECODER_INT_H_

void HexaDecoder_vidInit(void);

void HexaDecoder_vidDisplayNum(u8 Copy_u8Num);

void HexaDecoder_vidDisplayNum2(u8 Copy_u8Num);

void HexaDecoder_vidEnable(u8 Copy_u8SSG_ID);

void HexaDecoder_vidDisable(u8 Copy_u8SSG_ID);


#define SSG_ID_1 8
#define SSG_ID_2 21

#endif /* HEXADECODER_INT_H_ */
