/*
 * LCD_prog.c
 *
 *  Created on: Jun 10, 2023
 *      Author: Ahmed El-Gaafrawy
 */
// include public libraries
#include "../../Lib/stdTypes.h"

//include dependencies lower layer libraries
#include "../../MCAL/DIO/DIO_int.h"
#include <util/delay.h>

//my own libraries
#include "LCD_config.h"
#include "LCD_priv.h"

void LCD_enuInit(void)
{
    _delay_ms(35);

    DIO_vidSetPinDirection(RS_GRP , RS_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(RW_GRP , RW_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(EN_GRP , EN_PIN , DIO_OUTPUT);
    
    DIO_vidSetPinDirection(D7_GRP , D7_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(D6_GRP , D6_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(D5_GRP , D5_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(D4_GRP , D4_PIN , DIO_OUTPUT);

    #if LCD_MODE == EIGHT_BIT_MODE
        DIO_vidSetPinDirection(D3_GRP , D3_PIN , DIO_OUTPUT);
        DIO_vidSetPinDirection(D2_GRP , D2_PIN , DIO_OUTPUT);
        DIO_vidSetPinDirection(D1_GRP , D1_PIN , DIO_OUTPUT);
        DIO_vidSetPinDirection(D0_GRP , D0_PIN , DIO_OUTPUT);

        DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);
        vidWriteByteAndLatch(0x38);
    #elif LCD_MODE == FOUR_BIT_MODE
        DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);

        DIO_vidSetPinValue( D7_GRP, D7_PIN , 0);
        DIO_vidSetPinValue( D6_GRP, D6_PIN , 0);
        DIO_vidSetPinValue( D5_GRP, D5_PIN , 1);
        DIO_vidSetPinValue( D4_GRP, D4_PIN , 0);
        
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_HIGH);
        _delay_ms(1);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);
        _delay_ms(2);

        vidWriteByteAndLatch(0x28);
    #else
    #error LCD mode setting is wrong
    #endif

    DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);
    vidWriteByteAndLatch(0x0F);

    DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);
    vidWriteByteAndLatch(0x01);

    DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);
    vidWriteByteAndLatch(0x06);
}

void LCD_vidSendData(u8 Copy_u8Data)
{
    DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_HIGH);

    vidWriteByteAndLatch(Copy_u8Data);

}

void LCD_vidSendCommand(u8 Copy_u8Command)
{
    DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_LOW);

    vidWriteByteAndLatch(Copy_u8Command);
}

void LCD_vidWriteString(const char * Copy_pcString)
{
    // u8 Local_u8Index = 0;
    while ( * Copy_pcString != '\0')
    {
        DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_HIGH);
        vidWriteByteAndLatch(*Copy_pcString++);
        // vidWriteByteAndLatch(Copy_pcString[ Local_u8Index]);
        // Local_u8Index ++;
    }
}

void LCD_vidWriteIntegarNum(s32 Copy_s32Num)
{
    if (Copy_s32Num == 0)
    {
        DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_HIGH);
        vidWriteByteAndLatch('0');
    }
    else
    {
        if (Copy_s32Num < 0 )
        {
            DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_HIGH);
            vidWriteByteAndLatch('-');

            Copy_s32Num *=-1;
        }
        //10721 % 10
        //1 + 48 = '1'
        //1072 % 10 = 2
        // 2 + 48 = '2'
        // 107 -> 7
        //10
        u8 Local_au8Digits [12] = {0};//  { '1' , '0', '7' , '2', '1', 0}
        u8 Local_u8NumOfDigits = (u8CountDigitsInNum(Copy_s32Num)-1);

        for (s8 Local_s8Iter = Local_u8NumOfDigits ; Local_s8Iter >=0 ; Local_s8Iter --)
        {
            Local_au8Digits[Local_s8Iter] = ( Copy_s32Num %10)+ '0';
            Copy_s32Num /=10; 
        }
        for (u8 Local_u8Iter = 0 ; Local_au8Digits[Local_u8Iter] != 0 ; Local_u8Iter ++)
        {
            DIO_vidSetPinValue(RS_GRP , RS_PIN , DIO_HIGH);
            vidWriteByteAndLatch(Local_au8Digits[Local_u8Iter]);
        }

    }
}
// integar . fraction
void LCD_vidWriteFloatNum(f32 Copy_f32Num)
{

}

static u8 u8CountDigitsInNum(s32 Copy_s32Num)
{
    u8 Local_u8NumOfDigits = 0;
    while(Copy_s32Num != 0)
    {
        Copy_s32Num /=10;
        Local_u8NumOfDigits ++ ;
    }
    return Local_u8NumOfDigits;
}

static void vidWriteByteAndLatch(u8 Copy_u8Byte)
{
    #if LCD_MODE == EIGHT_BIT_MODE
        DIO_vidSetPinValue(RW_GRP,RW_PIN , DIO_LOW);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);

        DIO_vidSetPinValue( D7_GRP, D7_PIN , ((Copy_u8Byte >> 7)&1));
        DIO_vidSetPinValue( D6_GRP, D6_PIN , ((Copy_u8Byte >> 6)&1));
        DIO_vidSetPinValue( D5_GRP, D5_PIN , ((Copy_u8Byte >> 5)&1));
        DIO_vidSetPinValue( D4_GRP, D4_PIN , ((Copy_u8Byte >> 4)&1));
        DIO_vidSetPinValue( D3_GRP, D3_PIN , ((Copy_u8Byte >> 3)&1));
        DIO_vidSetPinValue( D2_GRP, D2_PIN , ((Copy_u8Byte >> 2)&1));
        DIO_vidSetPinValue( D1_GRP, D1_PIN , ((Copy_u8Byte >> 1)&1));
        DIO_vidSetPinValue( D0_GRP, D0_PIN , ((Copy_u8Byte >> 0)&1));

        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_HIGH);
        _delay_ms(1);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);

        _delay_ms(2);
    #elif LCD_MODE == FOUR_BIT_MODE
        DIO_vidSetPinValue(RW_GRP,RW_PIN , DIO_LOW);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);

        DIO_vidSetPinValue( D7_GRP, D7_PIN , ((Copy_u8Byte >> 7)&1));
        DIO_vidSetPinValue( D6_GRP, D6_PIN , ((Copy_u8Byte >> 6)&1));
        DIO_vidSetPinValue( D5_GRP, D5_PIN , ((Copy_u8Byte >> 5)&1));
        DIO_vidSetPinValue( D4_GRP, D4_PIN , ((Copy_u8Byte >> 4)&1));

        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_HIGH);
        _delay_ms(1);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);

        DIO_vidSetPinValue( D7_GRP, D7_PIN , ((Copy_u8Byte >> 3)&1));
        DIO_vidSetPinValue( D6_GRP, D6_PIN , ((Copy_u8Byte >> 2)&1));
        DIO_vidSetPinValue( D5_GRP, D5_PIN , ((Copy_u8Byte >> 1)&1));
        DIO_vidSetPinValue( D4_GRP, D4_PIN , ((Copy_u8Byte >> 0)&1));

        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_HIGH);
        _delay_ms(1);
        DIO_vidSetPinValue(EN_GRP,EN_PIN , DIO_LOW);

        _delay_ms(2);
    #else
    #error LCD mode setting is wrong
    #endif
}