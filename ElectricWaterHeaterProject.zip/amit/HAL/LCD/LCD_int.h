/*
 * LCD_int.h
 *
 *  Created on: Jun 10, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef LCD_INT_H_
#define LCD_INT_H_

void LCD_enuInit(void);

void LCD_vidSendData(u8 Copy_u8Data);

void LCD_vidSendCommand(u8 Copy_u8Command);

void LCD_vidWriteString(const char * Copy_pcString);

void LCD_vidWriteIntegarNum(s32 Copy_s32Num);

void LCD_vidWriteFloatNum(f32 Copy_f32Num);

void LCD_vidGoToPosition(u8 Copy_u8Row, u8 Copy_u8Column);

void LCD_vidDisplaySpecialChar(u8 * Copy_pu8Pattern, u8 Copy_u8NumOfPatterns,
							u8 Copy_u8StartPatternNum, u8 Row , u8 Col, u8 TypeOfDisplay);

#endif /* LCD_INT_H_ */
