/*
 * Temp_prog.c
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#include "../../Lib/stdTypes.h"
#include "Temp_config.h"
#include "Temp_int.h"
#include "../../MCAL/ADC/ADC_int.h"



void TemperatureSenor_init(void){
	ADC_vidInit();
}
u8 readTemperature(){
	u8 reading;
	reading = ADC_u8ReadPolling(TEMPERATURE_SENSOR_CHANNEL);
	return reading;
}
