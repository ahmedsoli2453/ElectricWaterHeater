/*
 * Temp_config.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_TEMPERATURESENSOR_TEMP_CONFIG_H_
#define HAL_TEMPERATURESENSOR_TEMP_CONFIG_H_

#define TEMPERATURE_SENSOR_CHANNEL  0

#endif /* HAL_TEMPERATURESENSOR_TEMP_CONFIG_H_ */
