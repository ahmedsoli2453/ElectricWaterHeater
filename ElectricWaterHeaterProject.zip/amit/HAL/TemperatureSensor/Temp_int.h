/*
 * Temp_int.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_TEMPERATURESENSOR_TEMP_INT_H_
#define HAL_TEMPERATURESENSOR_TEMP_INT_H_
#include "../../Lib/stdTypes.h"

void TemperatureSenor_init(void);
u8 readTemperature();

#endif /* HAL_TEMPERATURESENSOR_TEMP_INT_H_ */
