/*
 * L293D_prog.c
 *
 *  Created on: May 6, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#include "../../Lib/stdTypes.h"

#include "../../MCAL/DIO/DIO_int.h"
//#include "../../MCAL/PWM/PWM_int.h"

#include "L293D_config.h"
#include "L293D_priv.h"

void L293D_vidInit(void)
{
    DIO_vidSetPinDirection(L293D_EN1_GRP,L293D_EN1_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(L293D_EN2_GRP,L293D_EN2_PIN, DIO_OUTPUT);

    DIO_vidSetPinDirection(L293D_IN1_GRP,L293D_IN1_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(L293D_IN2_GRP,L293D_IN2_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(L293D_IN3_GRP,L293D_IN3_PIN, DIO_OUTPUT);
    DIO_vidSetPinDirection(L293D_IN4_GRP,L293D_IN4_PIN, DIO_OUTPUT);
}

void L293D_vidSetDirection(u8 Copy_u8MotorId , u8 Copy_u8Direction)
{
    if (Copy_u8Direction == L293D_CW)
    {
        if (Copy_u8MotorId==L293D_MOTOR_A)
        {
            DIO_vidSetPinValue(L293D_IN1_GRP, L293D_IN1_PIN, DIO_HIGH);
            DIO_vidSetPinValue(L293D_IN2_GRP, L293D_IN2_PIN, DIO_LOW);
        }
        else if(Copy_u8MotorId == L293D_MOTOR_B)
        {
            DIO_vidSetPinValue(L293D_IN3_GRP, L293D_IN3_PIN, DIO_HIGH);
            DIO_vidSetPinValue(L293D_IN4_GRP, L293D_IN4_PIN, DIO_LOW);
        }
    }
    else if (Copy_u8Direction == L293D_COUNTER_CW)
    {
        if (Copy_u8MotorId==L293D_MOTOR_A)
        {
            DIO_vidSetPinValue(L293D_IN1_GRP, L293D_IN1_PIN, DIO_LOW);
            DIO_vidSetPinValue(L293D_IN2_GRP, L293D_IN2_PIN, DIO_HIGH);
        }
        else if(Copy_u8MotorId == L293D_MOTOR_B)
        {
            DIO_vidSetPinValue(L293D_IN3_GRP, L293D_IN3_PIN, DIO_LOW);
            DIO_vidSetPinValue(L293D_IN4_GRP, L293D_IN4_PIN, DIO_HIGH);
        }
    }
}

void L293D_vidSetSpeed(u8 Copy_u8MotorId , u8 Copy_u8SpeedPercentage)
{
    if (Copy_u8MotorId==L293D_MOTOR_A)
    {
        if (Copy_u8SpeedPercentage == 0)
        {
            DIO_vidSetPinValue(L293D_EN1_GRP, L293D_EN1_PIN, DIO_LOW);
        }
        else if (Copy_u8SpeedPercentage == 100)
        {
            DIO_vidSetPinValue(L293D_EN1_GRP, L293D_EN1_PIN, DIO_HIGH);
        }
        else if (Copy_u8SpeedPercentage >0 && Copy_u8SpeedPercentage <100)
        {
            //Timer PWM 
        }
    }
    else if(Copy_u8MotorId == L293D_MOTOR_B)
    {
        if (Copy_u8SpeedPercentage == 0)
        {
            DIO_vidSetPinValue(L293D_EN2_GRP, L293D_EN2_PIN, DIO_LOW);
        }
        else if (Copy_u8SpeedPercentage == 100)
        {
            DIO_vidSetPinValue(L293D_EN2_GRP, L293D_EN2_PIN, DIO_HIGH);
        }
        else if (Copy_u8SpeedPercentage >0 && Copy_u8SpeedPercentage <100)
        {
            //Timer PWM 
        }
    }
}

