/*
 * HeaterLED_int.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_HEATERLED_HEATERLED_INT_H_
#define HAL_HEATERLED_HEATERLED_INT_H_

#include "../../Lib/stdTypes.h"
#include "../../MCAL/DIO/DIO_int.h"
#include "HeaterLED_config.h"

void HeaterLED_init(void);
void HeaterLED_ON(void);
void HeaterLED_OFF(void);
void HeaterLED_Toggle(void);


#endif /* HAL_HEATERLED_HEATERLED_INT_H_ */
