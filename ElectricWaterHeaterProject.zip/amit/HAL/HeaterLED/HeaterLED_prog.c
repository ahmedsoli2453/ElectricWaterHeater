/*
 * HeaterLED_prog.c
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#include "HeaterLED_int.h"
#include "HeaterLED_config.h"

void HeaterLED_init(void){
	DIO_vidSetPinDirection(HEATERLED_GROUP,HEATERLED_PIN, HEATERLED_OUTPUT);
}

void HeaterLED_ON(void){
	DIO_vidSetPinValue(HEATERLED_GROUP,HEATERLED_PIN,HEATERLED_HIGH);
}
void HeaterLED_OFF(void){
	DIO_vidSetPinValue(HEATERLED_GROUP,HEATERLED_PIN,HEATERLED_LOW);
}
void HeaterLED_Toggle(void){
	DIO_vidTogglePinValue(HEATERLED_GROUP, HEATERLED_PIN);
}
