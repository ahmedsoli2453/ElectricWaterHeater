/*
 * HeaterLED_config.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_HEATERLED_HEATERLED_CONFIG_H_
#define HAL_HEATERLED_HEATERLED_CONFIG_H_

#include "../../Lib/stdTypes.h"
#include "../../MCAL/DIO/DIO_int.h"

#define HEATERLED_GROUP DIO_GROUP_A
#define HEATERLED_PIN DIO_PIN_1

//#define HEATERLED_GROUP DIO_GROUP_D
//#define HEATERLED_PIN DIO_PIN_2


#define HEATERLED_OUTPUT DIO_OUTPUT
#define HEATERLED_HIGH DIO_HIGH
#define HEATERLED_LOW DIO_LOW


#endif /* HAL_HEATERLED_HEATERLED_CONFIG_H_ */
