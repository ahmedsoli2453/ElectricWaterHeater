/*
 * CoolingElement_int.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_COOLINGELEMENT_COOLINGELEMENT_INT_H_
#define HAL_COOLINGELEMENT_COOLINGELEMENT_INT_H_


void CoolingElement_init(void);
void CoolingElement_ON(void);
void CoolingElement_OFF(void);


#endif /* HAL_COOLINGELEMENT_COOLINGELEMENT_INT_H_ */
