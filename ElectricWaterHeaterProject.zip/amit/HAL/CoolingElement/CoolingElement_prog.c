/*
 * CoolingElement_prog.c
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#include "../../Lib/stdTypes.h"
#include "../../MCAL/DIO/DIO_int.h"

#include "CoolingElement_int.h"
#include "CoolingElement_config.h"
void CoolingElement_init(void){
	DIO_vidSetPinDirection(COOLINGELEMENT_GROUP, COOLINGELEMENT_PIN, COOLINGELEMENT_OUTPUT);
}

void CoolingElement_ON(void){
	DIO_vidSetPinValue(COOLINGELEMENT_GROUP, COOLINGELEMENT_PIN, COOLINGELEMENT_HIGH);
}


void CoolingElement_OFF(void){
	DIO_vidSetPinValue(COOLINGELEMENT_GROUP, COOLINGELEMENT_PIN, COOLINGELEMENT_LOW);
}
