/*
 * HeatingElement_int.h
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#ifndef HAL_HEATINGELEMENT_HEATINGELEMENT_INT_H_
#define HAL_HEATINGELEMENT_HEATINGELEMENT_INT_H_

//#include "HeatingElement_config.h"
//#include "../../MCAL/DIO/DIO_int.h"
void HeatingElement_init(void);
void HeatingElement_ON(void);
void HeatingElement_OFF(void);


#endif /* HAL_HEATINGELEMENT_HEATINGELEMENT_INT_H_ */
