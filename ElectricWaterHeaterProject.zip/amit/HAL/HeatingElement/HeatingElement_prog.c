/*
 * HeatingElement_prog.c
 *
 *  Created on: Aug 31, 2023
 *      Author: ahmed
 */

#include "../../Lib/stdTypes.h"
#include "../../MCAL/DIO/DIO_int.h"
#include "HeatingElement_config.h"
#include "HeatingElement_int.h"


void HeatingElement_init(void){
	DIO_vidSetPinDirection(HEATINGELEMENT_GROUP, HEATINGELEMENT_PIN, HEATINGELEMENT_OUTPUT);
}

void HeatingElement_ON(void){
	DIO_vidSetPinValue(HEATINGELEMENT_GROUP, HEATINGELEMENT_PIN, HEATINGELEMENT_HIGH);
}


void HeatingElement_OFF(void){
	DIO_vidSetPinValue(HEATINGELEMENT_GROUP, HEATINGELEMENT_PIN, HEATINGELEMENT_LOW);
}
