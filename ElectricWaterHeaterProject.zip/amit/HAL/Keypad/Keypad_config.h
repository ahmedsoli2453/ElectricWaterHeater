/*
 * Keypad_config.h
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef HAL_KEYPAD_KEYPAD_CONFIG_H_
#define HAL_KEYPAD_KEYPAD_CONFIG_H_

/*********** MAX 4x4 KEYPAD **********/
#define KEYPAD_ROW_NUM          4
#define KEYPAD_COL_NUM          4

/*********** Row Pin Configuration ************/
#define KEYPAD_R1_GRP           DIO_GROUP_C
#define KEYPAD_R1_PIN           DIO_PIN_0

#define KEYPAD_R2_GRP           DIO_GROUP_C
#define KEYPAD_R2_PIN           DIO_PIN_1

#define KEYPAD_R3_GRP           DIO_GROUP_C
#define KEYPAD_R3_PIN           DIO_PIN_2

#define KEYPAD_R4_GRP           DIO_GROUP_C
#define KEYPAD_R4_PIN           DIO_PIN_3

/*********** Columns Pin Configuration ************/
#define KEYPAD_C1_GRP           DIO_GROUP_D
#define KEYPAD_C1_PIN           DIO_PIN_3

#define KEYPAD_C2_GRP           DIO_GROUP_D
#define KEYPAD_C2_PIN           DIO_PIN_4

#define KEYPAD_C3_GRP           DIO_GROUP_D
#define KEYPAD_C3_PIN           DIO_PIN_5

#define KEYPAD_C4_GRP           DIO_GROUP_D
#define KEYPAD_C4_PIN           DIO_PIN_6

/*********** UI interface of Keys ************/
#define KEYPAD_KEY_VALUES           {\
                                     {'7', '8', '9', '/'},\
                                     {'4', '5', '6', 'x'},\
                                     {'1', '2', '3', '-'},\
                                     {'C', '0', '=', '+'}\
                                    }


#endif /* HAL_KEYPAD_KEYPAD_CONFIG_H_ */
