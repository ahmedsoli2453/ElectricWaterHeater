/*
 * Keypad_prog.c
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */
#include "../../Lib/stdTypes.h"

#include "../../MCAL/DIO/DIO_int.h"
#include <util/delay.h>

#include "Keypad_config.h"
#include "Keypad_priv.h"

void Keypad_vidInit()
{
    DIO_vidSetPinDirection(KEYPAD_R1_GRP , KEYPAD_R1_PIN , DIO_INPUT);
    DIO_vidSetPinDirection(KEYPAD_R2_GRP , KEYPAD_R2_PIN , DIO_INPUT);
    DIO_vidSetPinDirection(KEYPAD_R3_GRP , KEYPAD_R3_PIN , DIO_INPUT);
    DIO_vidSetPinDirection(KEYPAD_R4_GRP , KEYPAD_R4_PIN , DIO_INPUT);

    DIO_vidSetPinDirection(KEYPAD_C1_GRP , KEYPAD_C1_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(KEYPAD_C2_GRP , KEYPAD_C2_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(KEYPAD_C3_GRP , KEYPAD_C3_PIN , DIO_OUTPUT);
    DIO_vidSetPinDirection(KEYPAD_C4_GRP , KEYPAD_C4_PIN , DIO_OUTPUT);

    DIO_vidSetPinValue(KEYPAD_R1_GRP , KEYPAD_R1_PIN , DIO_PULL_UP);
    DIO_vidSetPinValue(KEYPAD_R2_GRP , KEYPAD_R2_PIN , DIO_PULL_UP);
    DIO_vidSetPinValue(KEYPAD_R3_GRP , KEYPAD_R3_PIN , DIO_PULL_UP);
    DIO_vidSetPinValue(KEYPAD_R4_GRP , KEYPAD_R4_PIN , DIO_PULL_UP);

    DIO_vidSetPinValue(KEYPAD_C1_GRP , KEYPAD_C1_PIN , DIO_HIGH);
    DIO_vidSetPinValue(KEYPAD_C2_GRP , KEYPAD_C2_PIN , DIO_HIGH);
    DIO_vidSetPinValue(KEYPAD_C3_GRP , KEYPAD_C3_PIN , DIO_HIGH);
    DIO_vidSetPinValue(KEYPAD_C4_GRP , KEYPAD_C4_PIN , DIO_HIGH);
}

u8 Keypad_u8GetPressedKey(void)
{
    u8 Local_u8KeyValue = KEYPAD_NOT_PRESSED;
    u8 Local_au8RowGrp[KEYPAD_ROW_NUM] = {KEYPAD_R1_GRP , KEYPAD_R2_GRP , KEYPAD_R3_GRP , KEYPAD_R4_GRP }; 
    u8 Local_au8RowPin[KEYPAD_ROW_NUM] = {KEYPAD_R1_PIN , KEYPAD_R2_PIN , KEYPAD_R3_PIN , KEYPAD_R4_PIN }; 
    u8 Local_au8ColGrp[KEYPAD_COL_NUM] = {KEYPAD_C1_GRP , KEYPAD_C2_GRP , KEYPAD_C3_GRP , KEYPAD_C4_GRP }; 
    u8 Local_au8ColPin[KEYPAD_COL_NUM] = {KEYPAD_C1_PIN , KEYPAD_C2_PIN , KEYPAD_C3_PIN , KEYPAD_C4_PIN }; 

    u8 Local_u8ColIter , Local_u8RowIter , Local_u8RowValue;

    for (Local_u8ColIter = 0 ; Local_u8ColIter < KEYPAD_COL_NUM ; Local_u8ColIter++)
    {
        //out zero current column
        DIO_vidSetPinValue(Local_au8ColGrp[Local_u8ColIter] , Local_au8ColPin [Local_u8ColIter] , DIO_LOW);

        //check all rows
        for (Local_u8RowIter = 0; Local_u8RowIter < KEYPAD_ROW_NUM ; Local_u8RowIter ++)
        {
            Local_u8RowValue = DIO_u8GetPinValue(Local_au8RowGrp[Local_u8RowIter] , Local_au8RowPin[Local_u8RowIter]);
            if (Local_u8RowValue == 0)
            {
                _delay_ms(3);
                Local_u8RowValue = DIO_u8GetPinValue(Local_au8RowGrp[Local_u8RowIter] , Local_au8RowPin[Local_u8RowIter]);
                if (Local_u8RowValue == 0)
                {
                    // take action
                    u8 Local_au8KeysValue[KEYPAD_ROW_NUM][KEYPAD_COL_NUM] = KEYPAD_KEY_VALUES;
                    Local_u8KeyValue = Local_au8KeysValue[Local_u8RowIter][Local_u8ColIter];
                    while(Local_u8RowValue == DIO_u8GetPinValue(Local_au8RowGrp[Local_u8RowIter] , Local_au8RowPin[Local_u8RowIter]));
                }

            }
        }

        //out one current column
        DIO_vidSetPinValue(Local_au8ColGrp[Local_u8ColIter] , Local_au8ColPin [Local_u8ColIter] , DIO_HIGH);
    }
    return Local_u8KeyValue;
}

