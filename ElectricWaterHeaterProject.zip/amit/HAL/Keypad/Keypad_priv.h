/*
 * Keypad_priv.h
 *
 *  Created on: Jul 7, 2023
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef HAL_KEYPAD_KEYPAD_PRIV_H_
#define HAL_KEYPAD_KEYPAD_PRIV_H_

#define KEYPAD_NOT_PRESSED          0xff

#endif /* HAL_KEYPAD_KEYPAD_PRIV_H_ */
